from setuptools import setup

setup(
    # Setup defined in pyproject.toml
)
